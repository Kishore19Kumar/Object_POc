// Copyright 2007 - 2021, Alan Antonuk and the rabbitmq-c contributors.
// SPDX-License-Identifier: mit

extern int asprintf(char **strp, const char *fmt, ...);
